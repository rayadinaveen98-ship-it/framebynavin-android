-- Disposable HTTP fixture, reconstructed from the read-only September 9, 2026
-- FrameByNavin production catalog inspection. No production rows or identities.
-- The existing RC8b migration is applied separately, byte-for-byte.
-- The baseline RPC signatures and bodies preserve the production contracts.
BEGIN;
CREATE TABLE public.creator_backups (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 device_key text, backup_kind text NOT NULL CHECK (backup_kind IN ('latest','daily','manual')),
 schema_version integer NOT NULL, app_version text, captured_at timestamptz NOT NULL,
 payload text NOT NULL, payload_sha256 text NOT NULL,
 project_count integer NOT NULL DEFAULT 0, idea_count integer NOT NULL DEFAULT 0,
 weekly_slot_count integer NOT NULL DEFAULT 0, active_reminder_count integer NOT NULL DEFAULT 0,
 created_at timestamptz NOT NULL DEFAULT now(), snapshot_day date
);
CREATE UNIQUE INDEX creator_backups_one_latest_per_user ON public.creator_backups(user_id) WHERE backup_kind='latest';
CREATE UNIQUE INDEX creator_backups_one_daily_per_day ON public.creator_backups(user_id,snapshot_day) WHERE backup_kind='daily';
CREATE INDEX creator_backups_user_captured_idx ON public.creator_backups(user_id,captured_at DESC);
CREATE INDEX creator_backups_user_kind_idx ON public.creator_backups(user_id,backup_kind,captured_at DESC);
CREATE TABLE public.creator_devices (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 device_key text NOT NULL, device_label text, app_version text,
 last_seen_at timestamptz NOT NULL DEFAULT now(), created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(user_id,device_key)
);
CREATE TABLE public.creator_profiles (
 user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
 display_name text, avatar_url text, created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(), username text, username_normalized text
);
CREATE UNIQUE INDEX creator_profiles_username_normalized_uq ON public.creator_profiles(username_normalized) WHERE username_normalized IS NOT NULL;
GRANT SELECT,INSERT,UPDATE,DELETE ON public.creator_backups,public.creator_devices,public.creator_profiles TO anon,authenticated,service_role;
ALTER TABLE public.creator_backups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_profiles ENABLE ROW LEVEL SECURITY;
DO $block$
DECLARE t text; prefix text;
BEGIN
 FOREACH t IN ARRAY ARRAY['creator_backups','creator_devices','creator_profiles'] LOOP
  prefix := CASE t WHEN 'creator_backups' THEN 'backups' WHEN 'creator_devices' THEN 'devices' ELSE 'profiles' END;
  EXECUTE format('CREATE POLICY %I ON public.%I FOR SELECT TO authenticated USING ((select auth.uid())=user_id)',prefix||'_select_own',t);
  EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT TO authenticated WITH CHECK ((select auth.uid())=user_id)',prefix||'_insert_own',t);
  EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE TO authenticated USING ((select auth.uid())=user_id) WITH CHECK ((select auth.uid())=user_id)',prefix||'_update_own',t);
  EXECUTE format('CREATE POLICY %I ON public.%I FOR DELETE TO authenticated USING ((select auth.uid())=user_id)',prefix||'_delete_own',t);
 END LOOP;
END;
$block$;

CREATE OR REPLACE FUNCTION public.save_creator_backup(
 p_device_key text,p_backup_kind text,p_schema_version integer,p_app_version text,
 p_captured_at timestamptz,p_snapshot_day date,p_payload text,p_payload_sha256 text,
 p_project_count integer,p_idea_count integer,p_weekly_slot_count integer,p_active_reminder_count integer
) RETURNS uuid LANGUAGE plpgsql SET search_path TO 'public' AS $function$
declare
 v_user uuid := auth.uid();
 v_id uuid;
begin
 if v_user is null then raise exception 'Authentication required'; end if;
 if p_backup_kind not in ('latest','daily','manual') then raise exception 'Invalid backup kind'; end if;
 if p_backup_kind = 'latest' then
  insert into public.creator_backups(
   user_id,device_key,backup_kind,schema_version,app_version,captured_at,snapshot_day,payload,payload_sha256,
   project_count,idea_count,weekly_slot_count,active_reminder_count
  ) values (
   v_user,p_device_key,'latest',p_schema_version,p_app_version,p_captured_at,p_snapshot_day,p_payload,p_payload_sha256,
   p_project_count,p_idea_count,p_weekly_slot_count,p_active_reminder_count
  ) on conflict (user_id) where backup_kind='latest'
  do update set device_key=excluded.device_key,schema_version=excluded.schema_version,app_version=excluded.app_version,
   captured_at=excluded.captured_at,snapshot_day=excluded.snapshot_day,payload=excluded.payload,
   payload_sha256=excluded.payload_sha256,project_count=excluded.project_count,idea_count=excluded.idea_count,
   weekly_slot_count=excluded.weekly_slot_count,active_reminder_count=excluded.active_reminder_count,created_at=now()
  returning id into v_id;
 elsif p_backup_kind = 'daily' then
  insert into public.creator_backups(
   user_id,device_key,backup_kind,schema_version,app_version,captured_at,snapshot_day,payload,payload_sha256,
   project_count,idea_count,weekly_slot_count,active_reminder_count
  ) values (
   v_user,p_device_key,'daily',p_schema_version,p_app_version,p_captured_at,p_snapshot_day,p_payload,p_payload_sha256,
   p_project_count,p_idea_count,p_weekly_slot_count,p_active_reminder_count
  ) on conflict (user_id,snapshot_day) where backup_kind='daily'
  do update set device_key=excluded.device_key,schema_version=excluded.schema_version,app_version=excluded.app_version,
   captured_at=excluded.captured_at,payload=excluded.payload,payload_sha256=excluded.payload_sha256,
   project_count=excluded.project_count,idea_count=excluded.idea_count,weekly_slot_count=excluded.weekly_slot_count,
   active_reminder_count=excluded.active_reminder_count,created_at=now()
  returning id into v_id;
  delete from public.creator_backups b where b.user_id=v_user and b.backup_kind='daily'
   and b.id not in (select id from public.creator_backups where user_id=v_user and backup_kind='daily'
    order by snapshot_day desc nulls last,captured_at desc limit 10);
 else
  insert into public.creator_backups(
   user_id,device_key,backup_kind,schema_version,app_version,captured_at,snapshot_day,payload,payload_sha256,
   project_count,idea_count,weekly_slot_count,active_reminder_count
  ) values (
   v_user,p_device_key,'manual',p_schema_version,p_app_version,p_captured_at,p_snapshot_day,p_payload,p_payload_sha256,
   p_project_count,p_idea_count,p_weekly_slot_count,p_active_reminder_count
  ) returning id into v_id;
 end if;
 return v_id;
end;
$function$;

CREATE OR REPLACE FUNCTION public.claim_creator_username(p_username text,p_display_name text DEFAULT NULL::text)
RETURNS jsonb LANGUAGE plpgsql SET search_path TO 'public' AS $function$
declare
 v_user_id uuid := auth.uid();
 v_username text := lower(trim(coalesce(p_username,'')));
 v_display_name text := nullif(trim(coalesce(p_display_name,'')),'');
 v_row public.creator_profiles%rowtype;
begin
 if v_user_id is null then raise exception 'Authentication required' using errcode='42501'; end if;
 if length(v_username)<3 or length(v_username)>24 or v_username !~ '^[a-z0-9_]+$' then
  raise exception 'Username must be 3-24 characters using letters, numbers or underscore' using errcode='22023';
 end if;
 if v_username in ('admin','administrator','framebynavin','support','help','official','system','moderator','null','undefined') then
  raise exception 'That username is reserved' using errcode='22023';
 end if;
 begin
  insert into public.creator_profiles(user_id,display_name,username,username_normalized,updated_at)
  values(v_user_id,v_display_name,v_username,v_username,now())
  on conflict(user_id) do update
   set display_name=coalesce(v_display_name,public.creator_profiles.display_name),username=v_username,
    username_normalized=v_username,updated_at=now()
  returning * into v_row;
 exception when unique_violation then
  raise exception 'Username is already taken' using errcode='23505';
 end;
 return jsonb_build_object('user_id',v_row.user_id,'display_name',coalesce(v_row.display_name,''),
  'username',coalesce(v_row.username,''),'avatar_url',coalesce(v_row.avatar_url,''),
  'created_at',v_row.created_at,'updated_at',v_row.updated_at);
end;
$function$;
REVOKE ALL ON FUNCTION public.save_creator_backup(text,text,integer,text,timestamptz,date,text,text,integer,integer,integer,integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.save_creator_backup(text,text,integer,text,timestamptz,date,text,text,integer,integer,integer,integer) TO anon,authenticated,service_role;
REVOKE ALL ON FUNCTION public.claim_creator_username(text,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.claim_creator_username(text,text) TO authenticated,service_role;
COMMIT;
