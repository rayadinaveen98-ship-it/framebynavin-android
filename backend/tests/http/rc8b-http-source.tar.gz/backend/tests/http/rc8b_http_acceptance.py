#!/usr/bin/env python3
"""RC8b local Supabase Auth/PostgREST acceptance. Disposable stack only.

No remote project, production credentials, or real user data are accepted.
The test-only service credential is used solely to remove synthetic Auth users.
"""
import hashlib
import json
import os
import secrets
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

EXPECTED_MIGRATION = '61425ebedad2ff4eaaf85b0c58dbe2382e0c35360f9b2416ab207c35139be45a'
TESTS = []


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def guard():
    require(os.environ.get('CI') == 'true', 'CI-only test')
    require(os.environ.get('RC8B_DISPOSABLE') == 'yes', 'Disposable opt-in required')
    require(not any(os.environ.get(k) for k in ('SUPABASE_ACCESS_TOKEN', 'SUPABASE_DB_URL', 'SUPABASE_PROJECT_REF', 'DATABASE_URL')), 'Remote database settings forbidden')
    api = os.environ['RC8B_LOCAL_API_URL'].rstrip('/')
    parsed = urllib.parse.urlparse(api)
    require(parsed.scheme == 'http' and parsed.hostname in ('127.0.0.1', 'localhost') and parsed.port == 54321 and not parsed.username, 'Unexpected API endpoint')
    db = urllib.parse.urlparse(os.environ['RC8B_LOCAL_DB_URL'])
    require(db.scheme in ('postgres', 'postgresql') and db.hostname in ('127.0.0.1', 'localhost') and db.port == 54322 and db.path == '/postgres', 'Unexpected database endpoint')
    require(os.environ.get('RC8B_LOCAL_PROJECT_ID') == 'framebynavin-rc8b-http-ci', 'Unexpected local project')
    require(os.environ['RC8B_LOCAL_ANON_KEY'] != os.environ['RC8B_LOCAL_SERVICE_KEY'], 'Keys must differ')
    return api


class HttpFailure(Exception):
    def __init__(self, status, body):
        self.status, self.body = status, body
        super().__init__(f'HTTP {status}: {body.get("code", body.get("error_code", "error")) if isinstance(body, dict) else "error"}')


def request(method, path, payload=None, token=None, admin=False, epoch=None):
    key = os.environ['RC8B_LOCAL_SERVICE_KEY' if admin else 'RC8B_LOCAL_ANON_KEY']
    headers = {'apikey': key, 'Authorization': 'Bearer ' + (key if admin else token or key), 'Content-Type': 'application/json', 'Accept': 'application/json'}
    if epoch is not None:
        headers['x-creator-write-epoch'] = str(epoch)
    body = None if payload is None else json.dumps(payload, separators=(',', ':')).encode()
    req = urllib.request.Request(API + path, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            raw = response.read()
            return response.status, json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        try:
            value = json.loads(raw) if raw else {}
        except ValueError:
            value = {'error': 'Non-JSON HTTP error'}
        raise HttpFailure(exc.code, value) from None


def rpc(name, payload=None, token=None, epoch=None):
    return request('POST', '/rest/v1/rpc/' + name, payload or {}, token, epoch=epoch)[1]


def denied(fn, codes=None):
    try:
        fn()
    except HttpFailure as exc:
        require(400 <= exc.status < 500, f'Unexpected HTTP failure: {exc}')
        if codes:
            require(isinstance(exc.body, dict) and exc.body.get('code') in codes, f'Wrong error code: {exc}')
        return
    raise AssertionError('An operation unexpectedly succeeded')


def passed(name):
    TESTS.append(name)
    print('PASS: ' + name, flush=True)


def sql(query):
    proc = subprocess.run(['psql', os.environ['RC8B_LOCAL_DB_URL'], '-X', '-A', '-t', '-v', 'ON_ERROR_STOP=1'], input=query, text=True, capture_output=True, timeout=20)
    require(proc.returncode == 0, 'Local SQL assertion failed: ' + (proc.stderr.strip() or 'unknown error'))
    return proc.stdout.strip()


def count(table, uid):
    require(table in ('creator_backups', 'creator_devices', 'creator_profiles'), 'Invalid table')
    return int(sql("select count(*) from public." + table + " where user_id='" + uid + "'::uuid;"))


def empty(uid):
    return all(count(t, uid) == 0 for t in ('creator_backups', 'creator_devices', 'creator_profiles'))


def status(token):
    return rpc('creator_cloud_status', token=token)


def backup(token, kind='latest', epoch=None, marker='original', day='2026-09-09'):
    payload = json.dumps({'synthetic': True, 'marker': marker}, sort_keys=True)
    return rpc('save_creator_backup', {
        'p_device_key': 'rc8b-device', 'p_backup_kind': kind, 'p_schema_version': 5,
        'p_app_version': 'rc8b-http-fixture', 'p_captured_at': datetime.now(timezone.utc).isoformat(),
        'p_snapshot_day': day, 'p_payload': payload, 'p_payload_sha256': hashlib.sha256(payload.encode()).hexdigest(),
        'p_project_count': 0, 'p_idea_count': 0, 'p_weekly_slot_count': 0, 'p_active_reminder_count': 0
    }, token, epoch)


def signup(label):
    email = 'rc8b-' + label + '-' + secrets.token_hex(8) + '@example.com'
    password = secrets.token_urlsafe(25) + 'aA1!'
    _, result = request('POST', '/auth/v1/signup', {'email': email, 'password': password})
    require(result.get('access_token') and result.get('refresh_token'), 'Local signup did not return session')
    uid = result['user']['id']
    _, identity = request('GET', '/auth/v1/user', token=result['access_token'])
    require(identity['id'] == uid, 'Auth token identity mismatch')
    return {'id': uid, 'email': email, 'password': password, **result}


def signin(user):
    _, result = request('POST', '/auth/v1/token?grant_type=password', {'email': user['email'], 'password': user['password']})
    require(result['user']['id'] == user['id'], 'Second session identity mismatch')
    return result


def refresh(session, uid):
    _, result = request('POST', '/auth/v1/token?grant_type=refresh_token', {'refresh_token': session['refresh_token']})
    require(result['user']['id'] == uid, 'Refresh changed identity')
    return result


def row_write(table, payload, token, epoch=None):
    return request('POST', '/rest/v1/' + table, payload, token, epoch=epoch)


def check_lock(uid):
    result = sql("begin; select pg_try_advisory_xact_lock(183, hashtext('" + uid + "')); rollback;")
    return 'f' in result.splitlines()


def concurrency_test(user):
    token, uid = user['access_token'], user['id']
    errors = []
    def writer():
        try:
            rpc('rc8b_test_hold_writer', {'p_seconds': 2}, token)
        except Exception as exc:
            errors.append(exc)
    thread = threading.Thread(target=writer)
    thread.start()
    deadline = time.monotonic() + 12
    try:
        acquired = False
        while time.monotonic() < deadline:
            if check_lock(uid):
                acquired = True
                break
            require(thread.is_alive(), 'Writer ended before obtaining lifecycle lock')
            time.sleep(.05)
        require(acquired, 'Writer did not obtain lifecycle lock')
        started = time.monotonic()
        deleted = rpc('creator_delete_owned_data', {'p_expected_generation': 0}, token)
        require(deleted == {'phase': 'deleted', 'generation': 1}, 'Concurrent deletion result mismatch')
        require(time.monotonic() - started > .1, 'Deletion did not wait for writer')
    finally:
        thread.join(timeout=8)
    require(not thread.is_alive() and not errors, 'Concurrent writer failed')
    require(empty(uid), 'Concurrent writer survived deletion')
    passed('concurrent HTTP writer serialized with deletion')


def main():
    global API
    API = guard()
    source = Path(os.environ['RC8B_MIGRATION_PATH']).read_bytes()
    require(hashlib.sha256(source).hexdigest() == EXPECTED_MIGRATION, 'Migration digest mismatch')
    require(sql('show server_version_num;').splitlines()[-1].startswith('170'), 'PostgreSQL 17 required')
    require(sql("select count(*) from pg_proc where pronamespace='public'::regnamespace and proname in ('creator_cloud_status','creator_delete_owned_data','creator_resume_owned_data');") == '3', 'Lifecycle RPCs missing')
    users = [signup(x) for x in ('a', 'b', 'c', 'd')]
    a, b, c, d = users
    ta, tb, tc = [u['access_token'] for u in (a, b, c)]
    a2 = refresh(signin(a), a['id'])
    passed('real signup, token identity, second session and refresh')
    denied(lambda: rpc('creator_cloud_status'))
    denied(lambda: rpc('creator_cloud_status', token='invalid.jwt.value'))
    denied(lambda: row_write('creator_devices', {'user_id': a['id'], 'device_key': 'anon'}))
    require(status(ta) == {'phase': 'active', 'generation': 0}, 'Initial lifecycle mismatch')
    require(status(tb) == {'phase': 'active', 'generation': 0}, 'Other account lifecycle mismatch')
    passed('anonymous and invalid-token rejection; initial lifecycle')
    backup(ta)
    backup(tb)
    backup(ta, 'daily')
    backup(ta, 'daily', marker='replacement')
    require(count('creator_backups', a['id']) == 2, 'Daily upsert duplicated rows')
    require(rpc('claim_creator_username', {'p_username': 'rc8b_a', 'p_display_name': 'Synthetic A'}, ta)['username'] == 'rc8b_a', 'Username claim failed')
    require(rpc('claim_creator_username', {'p_username': 'rc8b_b'}, tb)['username'] == 'rc8b_b', 'Other username claim failed')
    row_write('creator_devices', {'user_id': a['id'], 'device_key': 'device-a'}, ta)
    row_write('creator_devices', {'user_id': b['id'], 'device_key': 'device-b'}, tb)
    passed('legacy backup upserts, username claims and direct device writes')
    for table in ('creator_backups', 'creator_devices', 'creator_profiles'):
        _, rows = request('GET', '/rest/v1/' + table + '?select=user_id', token=tb)
        require(all(r['user_id'] == b['id'] for r in rows), 'Cross-owner read exposed rows')
    denied(lambda: row_write('creator_devices', {'user_id': b['id'], 'device_key': 'stolen'}, ta), {'42501'})
    denied(lambda: request('PATCH', '/rest/v1/creator_profiles?user_id=eq.' + a['id'], {'user_id': b['id']}, ta), {'42501'})
    denied(lambda: rpc('claim_creator_username', {'p_username': 'rc8b_b'}, ta), {'23505'})
    denied(lambda: rpc('creator_delete_owned_data', {'p_expected_generation': 0, 'p_user_id': b['id']}, ta), {'PGRST202', 'PGRST203'})
    passed('cross-account RLS, ownership reassignment and username uniqueness')
    require(rpc('creator_delete_owned_data', {'p_expected_generation': 0}, a2['access_token']) == {'phase': 'deleted', 'generation': 1}, 'Delete result mismatch')
    require(empty(a['id']) and count('creator_backups', b['id']) == 1, 'Deletion affected wrong owner')
    require(rpc('creator_delete_owned_data', {'p_expected_generation': 0}, ta) == {'phase': 'deleted', 'generation': 1}, 'Deletion retry not idempotent')
    for token, epoch in ((ta, None), (ta, 0), (a2['access_token'], 1)):
        denied(lambda t=token, e=epoch: backup(t, epoch=e), {'42501'})
    denied(lambda: rpc('creator_resume_owned_data', {'p_expected_generation': 0}, ta), {'42501'})
    passed('atomic owner deletion, idempotent retry and tombstone rejection')
    require(rpc('creator_resume_owned_data', {'p_expected_generation': 1}, ta) == {'phase': 'active', 'generation': 2}, 'Reactivation result mismatch')
    require(empty(a['id']), 'Reactivation restored deleted records')
    for epoch in (None, 0, 1, 3):
        denied(lambda e=epoch: backup(ta, epoch=e), {'42501'})
    denied(lambda: rpc('creator_delete_owned_data', {'p_expected_generation': 0}, ta), {'42501'})
    denied(lambda: rpc('creator_delete_owned_data', {'p_expected_generation': 1}, ta), {'42501'})
    backup(ta, epoch=2, marker='fresh')
    rpc('claim_creator_username', {'p_username': 'rc8b_a2'}, ta, 2)
    row_write('creator_devices', {'user_id': a['id'], 'device_key': 'fresh'}, ta, 2)
    denied(lambda: request('DELETE', '/rest/v1/creator_backups?user_id=eq.' + a['id'], token=ta), {'42501'})
    require(rpc('creator_delete_owned_data', {'p_expected_generation': 2}, ta) == {'phase': 'deleted', 'generation': 3}, 'Second deletion mismatch')
    require(empty(a['id']) and count('creator_backups', b['id']) == 1, 'Second deletion affected other owner')
    passed('explicit reactivation, epoch fencing and second deletion')
    concurrency_test(c)
    backup(d['access_token'])
    row_write('creator_devices', {'user_id': d['id'], 'device_key': 'auth-cascade'}, d['access_token'])
    rpc('claim_creator_username', {'p_username': 'rc8b_d'}, d['access_token'])
    old_token = d['access_token']
    request('DELETE', '/auth/v1/admin/users/' + d['id'], admin=True)
    require(empty(d['id']), 'Auth cascade left creator records')
    require(sql("select count(*) from creator_guard_v183.lifecycle where user_id='" + d['id'] + "'::uuid;") == '0', 'Auth cascade left lifecycle row')
    denied(lambda: backup(old_token), {'42501'})
    require(count('creator_backups', b['id']) == 1, 'Auth deletion affected other owner')
    passed('real Auth admin deletion, cascades and expired-identity resurrection rejection')
    require(status(tb) == {'phase': 'active', 'generation': 0}, 'Other owner lifecycle changed')
    require(count('creator_backups', b['id']) == 1, 'Other owner data changed')
    print(json.dumps({'rc8b_http': 'passed', 'checks': TESTS, 'synthetic_accounts': 4, 'production_changes': False, 'migration_sha256': EXPECTED_MIGRATION, 'managed_supabase': 'not_tested'}, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('FAIL: ' + str(exc), file=sys.stderr)
        sys.exit(1)
