-- Disposable local-only test helper. Never deploy this RPC to production.
-- SECURITY INVOKER and auth.uid() preserve normal ownership and lifecycle guards.
CREATE OR REPLACE FUNCTION public.rc8b_test_hold_writer(p_seconds numeric)
RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = '' AS $function$
DECLARE v_payload text := '{"synthetic":true,"marker":"concurrency"}';
BEGIN
 IF p_seconds IS NULL OR p_seconds < 0 OR p_seconds > 3 THEN
  RAISE EXCEPTION 'Invalid test delay' USING ERRCODE = '22023';
 END IF;
 PERFORM public.save_creator_backup(
  'rc8b-concurrency', 'latest', 5, 'rc8b-http-fixture', now(), current_date,
  v_payload, '787931f1cfabf59e05af48f2a61849f893d68889dd6738605c632f94b65063cb',
  0, 0, 0, 0);
 PERFORM pg_catalog.pg_sleep(p_seconds::double precision);
END;
$function$;
REVOKE ALL ON FUNCTION public.rc8b_test_hold_writer(numeric) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.rc8b_test_hold_writer(numeric) TO authenticated;
